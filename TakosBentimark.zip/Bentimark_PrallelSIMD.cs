﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    class Bentimark_PrallelSIMD
    {
            static string GetFormatStr(int n)
            {
                if (n < 10)
                    return "    " + n;

                if (n < 100)
                    return "   " + n;

                if (n < 1000)
                    return "  " + n;

                if (n < 10000)
                    return " " + n;

                return "" + n;
            }

            public static (int time, string str) PraSIMD()
            {
                Console.WriteLine();
                Console.WriteLine("単純並列平行性能テスト開始");
                int[] resutls = new int[8];
                resutls[0] = _mm_shift_int_parallel_Start();
                resutls[1] = _mm_add_pd_parallel_Start();
                resutls[2] = _mm_mul_pd_parallel_Start();
                resutls[3] = _mm_sqrt_pd_parallel_Start();
                resutls[4] = _mm_dot_pd_parallel_Start();
                resutls[5] = _mm_max_pd_parallel_Start();
                resutls[6] = _mm_shuffle_pd_parallel_Start();
                resutls[7] = _mm_xor_pd_parallel_Start();
                Console.WriteLine();
                Console.WriteLine("単純並列平行性能テスト終了");
                Console.WriteLine();
                var points = resutls.Select(x => (int)(Math.Sqrt(Math.Sqrt(x)) * 100)).ToArray();
                int rtn =(int)( (1.0*points.Sum() / 100) * (1.0*points.Sum() / 100) * (1.0*points.Sum() / 100) * (1.0*points.Sum() / 100) / 10000);
                int i = 0;
                string rtnStr = "単純並列平行性能テスト結果\r\n\r\n";
                rtnStr += "単純並列平行　シフト演算 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　加算　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　乗算　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　平方根　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　内積　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　最大値　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　入れ替え　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
                rtnStr += "単純並列平行　ビット演算 点数 = " + GetFormatStr(points[i]) + "\r\n\r\n"; i++;
                rtnStr += "単純並列平行  総合 　　　点数 = " + GetFormatStr(rtn) + "\r\n\r\n\r\n";
                Console.WriteLine(rtnStr);
                return (rtn, rtnStr);
            }

            static public int _mm_shift_int_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_shift_int_parallel ベクトルの並列平行ビットシフト 1,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128((int)r.NextDouble(), (int)r.NextDouble(), (int)r.NextDouble(), (int)r.NextDouble());
                    byte c = (byte)r.Next(0, 32);

                    for (int j = 0; j < 100000; j++)
                    {
                        var vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);
                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);

                        vec2 = Sse2.ShiftLeftLogical128BitLane(vec1, c);


                    }
                });
                stopwatch.Stop();
                return (int)(50000000 / 8 / stopwatch.ElapsedMilliseconds);
            }


            static public int _mm_xor_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_xor_ps_parallel ベクトル同士の並列平行XOR演算 16,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 1600000; j++)
                    {
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);
                        vec1 = Sse2.Xor(vec1, vec1);

                    }
                });
                stopwatch.Stop();

                return (int)(100000000 / stopwatch.ElapsedMilliseconds);
            }


            static public int _mm_add_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_add_pd_parallel ベクトル同士の並列平行加算 16,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 1600000; j++)
                    {
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);
                        vec1 = Sse2.Add(vec1, vec1);

                    }
                });
                stopwatch.Stop();

                return (int)(100000000 / stopwatch.ElapsedMilliseconds);

            }
            static public int _mm_mul_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_mul_pd_parallel　ベクトル同士の並列平行乗算 16,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();

                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 1600000; j++)
                    {
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);
                        vec1 = Sse2.Multiply(vec1, vec1);

                    }
                });
                stopwatch.Stop();
                return (int)(100000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _mm_sqrt_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_sqrt_pd_parallel　ベクトルの平方根を並列平行で計算 1,600,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 160000; j++)
                    {
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);
                        vec1 = Sse2.Sqrt(vec1);

                    }
                });
                stopwatch.Stop();

                return (int)(10000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _mm_dot_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_dot_pd_parallel ベクトル同士の内積を並列平行で計算 8,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 800000; j++)
                    {
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);
                        vec1 = Sse41.DotProduct(vec1, vec1, 0b11111111);

                    }
                });
                stopwatch.Stop();

                return (int)(50000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _mm_max_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_dot_pd_parallel ベクトル内の最大値を並列平行で計算 16,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 1600000; j++)
                    {
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);
                        vec1 = Sse2.Max(vec1, vec1);

                    }
                });
                stopwatch.Stop();
                return (int)(100000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _mm_shuffle_pd_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mm_shuffle_pd_parallel ベクトル内の要素を並列平行で並べ替え計算 16,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    var vec1 = Sse2.SetVector128(r.NextDouble(), r.NextDouble());

                    for (int j = 0; j < 1600000; j++)
                    {
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);
                        vec1 = Sse2.Shuffle(vec1, vec1, 0b11);

                    }
                });
                stopwatch.Stop();
                return (int)(100000000 / stopwatch.ElapsedMilliseconds);
            }
        
    }
}
