﻿using System;
using System.Threading.Tasks;
using System.Threading;
using System.Runtime.Intrinsics.X86;
using System.Diagnostics;
using System.Linq;
using System.IO;
namespace ConsoleApp10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
            Benti.Init();
            BentiRunner.Run();
            StreamWriter sw = new StreamWriter(GetFileName());
            sw.WriteLine(BentiRunner.Buf);
            sw.Close();
            Console.WriteLine(BentiRunner.Buf);
            string GetFileName() => "reslt" + DateTime.Now.Day + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + DateTime.Now.Millisecond + ".txt";
        }
    }
    class BentiRunner
    {
        static public string Buf = "";
        static string GetFormatStr(int n)
        {
            if (n < 10)
                return "    " + n;

            if (n < 100)
                return "   " + n;

            if (n < 1000)
                return "  " + n;

            if (n < 10000)
                return " " + n;

            return "" + n;
        }
        static public void Run()
        {
            int[] results = new int[2];
            var tmp = Bentimark_PrallelSIMD.PraSIMD();
            results[0] = tmp.time;
            Buf += tmp.str;
            tmp = Bentimark_Prallel.Pra();
            results[1] = tmp.time;
            Buf += tmp.str;


            
            Buf += "並列ベクトル演算 " + results[0] + " \r\n";
            Buf += "並列通常演算　　 " + results[1] + " \r\n";


        }
    }
    class Benti
    {
      
        static public void Init()
        {
            Console.WriteLine("準備開始");
            for (int i = 0; i < 1000000000; i++)
            {
                var tmp = Sse2.SetAllVector128(0);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp); Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp); Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp); Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp); Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp); Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
                Sse2.Add(tmp, tmp);
            }
            Console.WriteLine("準備終わり");
        }

     
    }
}