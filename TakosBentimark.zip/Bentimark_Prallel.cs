﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    class Bentimark_Prallel
    {
        static string GetFormatStr(int n)
        {
            if (n < 10)
                return "    " + n;

            if (n < 100)
                return "   " + n;

            if (n < 1000)
                return "  " + n;

            if (n < 10000)
                return " " + n;

            return "" + n;
        }

        public static (int time, string str) Pra()
        {
            Console.WriteLine();
            Console.WriteLine("単純並列性能テスト開始");
            int[] resutls = new int[8];
            resutls[0] = _shift_parallel_Start();
            resutls[1] = _add_parallel_Start();
            resutls[2] = _mul_parallel_Start();
            resutls[3] = _sqrt_parallel_Start();
            resutls[4] = _dot_parallel_Start();
            resutls[5] = _max_parallel_Start();
            resutls[6] = _shuffle_parallel_Start();
            resutls[7] = _xor_parallel_Start();
            Console.WriteLine();
            Console.WriteLine("単純並列性能テスト終了");
            Console.WriteLine();
            var points = resutls.Select(x => (int)(Math.Sqrt(Math.Sqrt(x)) * 100)).ToArray();
            int rtn = (int)((1.0*points.Sum() / 100) * (1.0 * points.Sum() / 100) * (1.0 * points.Sum() / 100) * (1.0 * points.Sum() / 100))*5 / 10000;
            int i = 0;
            string rtnStr = "単純並列性能テスト結果\r\n\r\n";
            rtnStr += "単純並列　シフト演算 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　加算　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　乗算　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　平方根　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　内積　　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　最大値　　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　入れ替え　 点数 = " + GetFormatStr(points[i]) + "\r\n"; i++;
            rtnStr += "単純並列　ビット演算 点数 = " + GetFormatStr(points[i]) + "\r\n\r\n"; i++;
            rtnStr += "単純並列  総合 　　　点数 = " + GetFormatStr(rtn) + "\r\n\r\n\r\n";
            Console.WriteLine(rtnStr);
            return (rtn, rtnStr);
        }
        static volatile int n0;
        static volatile int n1;
        static volatile int n2;
        static volatile float f0;
        static volatile float f1;
        static volatile float f2;
        static volatile float f3;
        static volatile float f4;
        static volatile float f5;
        static volatile float f6;
        static volatile float f7;

        static volatile float f8;
        static volatile float f9;
        static volatile float f10;
        static volatile float f11;
        static volatile float f12;
        static volatile float f13;
        static volatile float f14;
        static volatile float f15;

        static volatile byte b0;
        static volatile byte b1;
        static public int _shift_parallel_Start()
            {
           
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_shift_int_parallel 並列ビットシフト 100,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
            Parallel.For(0, 100, i =>
            {
                lock (Viewing)
                {
                    Console.CursorLeft = 0;
                    Console.Write(Interlocked.Increment(ref cnt));
                }
                n0 = (int)r.NextDouble();
                byte c = (byte)r.Next(0, 32);

                for (int j = 0; j < 100000; j++)
                {
                        n1 = n0 << c;
                        n1 = n0 << c;
                        n1 = n0 << c;
                        n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                    n1 = n0 << c;
                }
            });
                stopwatch.Stop();
                return (int)(50000000 / 8/10 / stopwatch.ElapsedMilliseconds);
            }


            static public int _xor_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_xor_parallel 並列XOR演算 160,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    n0 = (int)r.NextDouble();
                    n1 = (int)r.NextDouble();
                    n2 = (int)r.NextDouble();
                                      
                    for (int j = 0; j < 160000; j++)
                    {
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;

                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                        n0 = n1 ^ n2;
                    }
                });
                stopwatch.Stop();
                 return (int)(10000000 / stopwatch.ElapsedMilliseconds);
            }


            static public int _add_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_add_pd_parallel 並列加算 160,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    f0=(float)r.NextDouble();
                    f1=(float)r.NextDouble();
                    f2=(float)r.NextDouble();

                    for (int j = 0; j < 16000; j++)
                    {
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                        f0 = f1 + f2;
                    }
                });
                stopwatch.Stop();

                return (int)(1000000 / stopwatch.ElapsedMilliseconds);

            }
            static public int _mul_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_mul_parallel　並列乗算 160,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();

                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                f0 =(float) r.NextDouble();
                f1 =(float) r.NextDouble();
                f2 =(float)r.NextDouble();

                    for (int j = 0; j < 16000; j++)
                    {
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;  
                        f0 = f1 * f2;

                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                        f0 = f1 * f2;
                    }
                });
                stopwatch.Stop();
                return (int)(1000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _sqrt_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_sqrt_parallel　平方根並列 16,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                f0 = (float)(r.NextDouble());
                f1 = (float)(r.NextDouble());
                    for (int j = 0; j < 16000; j++)
                    {
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float) Math.Sqrt(f1);
                        f0 =(float)Math.Sqrt(f1);

                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);











                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);
                        f0 = (float)Math.Sqrt(f1);




















































































































































































































































































































                    }
                });
                stopwatch.Stop();
                return (int)(1000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _dot_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_dot_parallel ベクトルの内積を並列で計算 2,000,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                   f0=(int)r.NextDouble();
                   f1=(int)r.NextDouble();
                   f2=(int)r.NextDouble();
                   f3=(int)r.NextDouble();
                    f4 = (int)r.NextDouble();

                    for (int j = 0; j < 200000; j++)
                    {
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2; 
                        f4 = f0 * f3 + f1 * f2;

                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                        f4 = f0 * f3 + f1 * f2;
                    }
                });
                stopwatch.Stop();

                return (int)(50000000 / 4/stopwatch.ElapsedMilliseconds);
            }

            static public int _max_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_max_parallel ベクトル内の最大値を並列平行で計算 1,600,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    f0=(int)r.NextDouble();
                    f1=(int)r.NextDouble();
                    f2 = (int)r.NextDouble();

                    for (int j = 0; j < 160000; j++)
                    {
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;   
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                        f0 = f1 > f2 ? f2 : f1;
                    }
                });
                stopwatch.Stop();
                return (int)(10000000 / stopwatch.ElapsedMilliseconds);
            }

            static public int _shuffle_parallel_Start()
            {
                Console.CursorLeft = 1;
                Console.WriteLine();
                Console.WriteLine("_shuffle_parallel ベクトル内の要素を並列平行で並べ替え計算 160,000*100*256 loop Start");
                Random r = new Random();

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();
                int cnt = 0;
                object Viewing = new object();
                Parallel.For(0, 100, i =>
                {
                    lock (Viewing)
                    {
                        Console.CursorLeft = 0;
                        Console.Write(Interlocked.Increment(ref cnt));
                    }
                    f0 = (int)r.NextDouble();
                    f1 = (int)r.NextDouble();
                    f2 = (int)r.NextDouble();
                    f3 = (int)r.NextDouble();
                    b1 = 1;
                    b0 = 1;
                    for (int j = 0; j < 16000; j++)
                    {
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;
                        if (b0 == 0) f2 = f0;
                        else f1 = f0;
                        if (b1 == 0) f3 = f1;
                        else f4 = f1;

                    }
                });
                stopwatch.Stop();
                return (int)(1000000 / stopwatch.ElapsedMilliseconds);
            }
        
    }
}
